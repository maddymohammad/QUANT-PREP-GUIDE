"""
signals.py
----------
Turns the spread into trading signals using a rolling z-score.

Why a ROLLING window?
    Using the full-sample mean/std of the spread would leak future
    information into past decisions ("look-ahead bias") — a cardinal sin
    in backtesting.  A rolling window only uses data available at the
    time of each decision.

Trading logic (classic Bollinger-style bands on the spread):
    z >  +entry_z   -> spread unusually HIGH  -> SHORT the spread
                       (short B, long beta units of A)
    z <  -entry_z   -> spread unusually LOW   -> LONG the spread
    |z| < exit_z    -> spread back to normal  -> CLOSE the position
"""

import numpy as np
import pandas as pd


def rolling_zscore(spread, window=60):
    """
    z_t = (S_t - rolling_mean_t) / rolling_std_t

    The first `window-1` values are NaN because there isn't enough
    history yet — the backtester simply stays flat there.
    """
    s = pd.Series(spread)
    mean = s.rolling(window).mean()
    std = s.rolling(window).std()
    return (s - mean) / std


def generate_positions(zscore, entry_z=2.0, exit_z=0.5):
    """
    Convert z-scores into a position series in {-1, 0, +1}.

    +1 = long the spread, -1 = short the spread, 0 = flat.

    The loop carries yesterday's position forward until an exit or an
    opposite entry fires — i.e. positions are "sticky", like a real book.
    """
    z = zscore.values
    positions = np.zeros(len(z))
    pos = 0
    for t in range(len(z)):
        if np.isnan(z[t]):
            positions[t] = 0
            continue
        if pos == 0:
            if z[t] > entry_z:
                pos = -1          # spread too high -> bet it falls
            elif z[t] < -entry_z:
                pos = +1          # spread too low  -> bet it rises
        elif pos == 1 and z[t] > -exit_z:
            pos = 0               # reverted -> take profit / stop
        elif pos == -1 and z[t] < exit_z:
            pos = 0
        positions[t] = pos
    return pd.Series(positions, index=zscore.index)
