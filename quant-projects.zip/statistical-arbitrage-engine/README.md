# Statistical Arbitrage Engine — Cointegration-Based Pairs Trading

A research-grade backtesting pipeline for mean-reversion pairs trading, built from scratch in Python. The project covers the full quant research workflow: hypothesis testing (Engle-Granger cointegration), signal construction (rolling z-scores), honest backtesting (signal lag + transaction costs), and institutional performance analytics.

## Why this project

Pairs trading is the canonical statistical-arbitrage strategy: find two assets bound by a long-run equilibrium, and trade temporary deviations of their spread. The hard part is not the idea — it is doing the statistics correctly and the backtest honestly. This repo emphasizes both.

## Methodology

1. **Data** — real prices via `yfinance`, or a reproducible synthetic mode that simulates a cointegrated pair by construction (GBM driver + Ornstein-Uhlenbeck spread), so results are verifiable offline.
2. **Cointegration testing** — Engle-Granger two-step: OLS hedge ratio, then Augmented Dickey-Fuller test on the residual spread. The strategy refuses pairs that fail at the 5% level.
3. **Mean-reversion speed** — AR(1) half-life estimate of the spread, used to sanity-check the signal look-back window.
4. **Signals** — rolling z-score of the spread (no look-ahead), enter at |z| > 2, exit at |z| < 0.5 (hysteresis reduces churn).
5. **Backtest** — positions lagged one day; 5 bps one-way transaction costs on traded notional; dollar-neutral spread PnL.
6. **Analytics** — Sharpe, Sortino, max drawdown, Calmar, CAGR, trade count, total cost drag.

## Results (synthetic mode, seed=42, net of costs)

| Metric | Value |
|---|---|
| ADF p-value | 0.0001 (cointegrated) |
| Spread half-life | 15.6 days |
| Annualised return | 2.13% |
| Sharpe ratio | 1.02 |
| Max drawdown | −2.05% |
| Round-trip trades | 29 |

![results](results.png)

## Run it

```bash
pip install -r requirements.txt
python main.py                       # reproducible synthetic data
python main.py --live KO PEP         # real Yahoo Finance data
python main.py --entry 1.5 --cost 10 # tweak thresholds / costs
```

## Design decisions I'd defend in an interview

- **Signal lag (`shift(1)`)** — eliminates look-ahead bias, the most common backtest error.
- **Rolling statistics only** — full-sample z-scores would leak future information.
- **Costs modeled explicitly** — gross Sharpe is a vanity metric.
- **Cointegration gate** — trading a non-cointegrated pair is gambling, not arbitrage.

## Limitations & extensions

- Hedge ratio is estimated in-sample; a rolling or Kalman-filter beta would be more realistic.
- No stop-loss for structural breaks (e.g., M&A killing the relationship).
- Extensions: multi-pair portfolio with Johansen test, walk-forward parameter selection, borrow costs for the short leg.

## Project structure

```
data_loader.py    # live (yfinance) + synthetic cointegrated data
cointegration.py  # Engle-Granger test, hedge ratio, half-life
signals.py        # rolling z-score, entry/exit state machine
backtester.py     # lagged, cost-aware, dollar-neutral backtest
metrics.py        # Sharpe, Sortino, drawdown, Calmar
main.py           # end-to-end pipeline + plots
KEYWORDS.md       # line-by-line explanation of every concept used
```
