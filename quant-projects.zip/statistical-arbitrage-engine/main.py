"""
main.py
-------
End-to-end pipeline:

    load prices -> test cointegration -> build signals
    -> backtest with costs -> report metrics -> save plots

Run with:
    python main.py                # synthetic, reproducible data
    python main.py --live KO PEP  # real Yahoo Finance data (needs internet)
"""

import argparse

import matplotlib
matplotlib.use("Agg")  # render plots to files, no display window needed
import matplotlib.pyplot as plt
import pandas as pd

from data_loader import load_prices
from cointegration import engle_granger_test, half_life
from signals import rolling_zscore, generate_positions
from backtester import backtest_pair
from metrics import summarise


def run(use_live=False, tickers=("KO", "PEP"),
        window=60, entry_z=2.0, exit_z=0.5, cost_bps=5.0):

    # ---------- 1. Data ----------
    prices = load_prices(use_live=use_live, tickers=tickers)
    a_name, b_name = prices.columns[:2]
    print(f"Loaded {len(prices)} days of prices for {a_name} / {b_name}\n")

    # ---------- 2. Cointegration analysis ----------
    res = engle_granger_test(prices[a_name], prices[b_name])
    hl = half_life(res["spread"])
    print("=== Engle-Granger cointegration test ===")
    print(f"Hedge ratio (beta) : {res['beta']:.4f}")
    print(f"ADF statistic      : {res['adf_stat']:.3f}")
    print(f"p-value            : {res['p_value']:.4f}")
    print(f"Cointegrated @5%?  : {res['cointegrated_5pct']}")
    print(f"Spread half-life   : {hl:.1f} days\n")

    if not res["cointegrated_5pct"]:
        print("WARNING: pair failed the cointegration test — "
              "trading it would be statistically unjustified.")

    # ---------- 3. Signals ----------
    spread = pd.Series(res["spread"], index=prices.index)
    z = rolling_zscore(spread, window=window)
    positions = generate_positions(z, entry_z=entry_z, exit_z=exit_z)

    # ---------- 4. Backtest ----------
    results = backtest_pair(prices, res["beta"], positions, cost_bps=cost_bps)

    # ---------- 5. Report ----------
    print("=== Backtest performance (net of costs) ===")
    print(summarise(results).to_string(), "\n")

    # ---------- 6. Plots ----------
    fig, axes = plt.subplots(3, 1, figsize=(11, 10), sharex=True)

    axes[0].plot(prices.index, prices[a_name], label=a_name)
    axes[0].plot(prices.index, prices[b_name], label=b_name)
    axes[0].set_title("Price series")
    axes[0].legend()

    axes[1].plot(z.index, z.values, color="tab:purple", lw=0.8)
    for level, style in [(entry_z, "--"), (-entry_z, "--"),
                         (exit_z, ":"), (-exit_z, ":")]:
        axes[1].axhline(level, color="grey", ls=style, lw=0.8)
    axes[1].set_title(f"Spread z-score (rolling {window}d) with entry/exit bands")

    axes[2].plot(results.index, results["equity"], color="tab:green")
    axes[2].set_title("Strategy equity curve (net of transaction costs)")

    fig.tight_layout()
    fig.savefig("results.png", dpi=150)
    print("Saved plots to results.png")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Pairs trading backtest")
    parser.add_argument("--live", nargs=2, metavar=("TICKER_A", "TICKER_B"),
                        help="use live Yahoo Finance data for these tickers")
    parser.add_argument("--window", type=int, default=60)
    parser.add_argument("--entry", type=float, default=2.0)
    parser.add_argument("--exit", type=float, default=0.5)
    parser.add_argument("--cost", type=float, default=5.0,
                        help="one-way cost in basis points")
    args = parser.parse_args()

    run(use_live=args.live is not None,
        tickers=tuple(args.live) if args.live else ("KO", "PEP"),
        window=args.window, entry_z=args.entry,
        exit_z=args.exit, cost_bps=args.cost)
