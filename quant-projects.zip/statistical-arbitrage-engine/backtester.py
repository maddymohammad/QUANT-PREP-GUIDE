"""
backtester.py
-------------
Vectorised event-free backtester for the pairs strategy.

Design choices worth mentioning in interviews:
1. SIGNAL LAG: today's position is decided on yesterday's z-score
   (`positions.shift(1)`), so the strategy never trades on information
   it couldn't have had.  Forgetting this shift is the single most
   common backtesting bug.
2. TRANSACTION COSTS: every change in position pays a cost proportional
   to traded notional.  Strategies that look great gross often die net.
3. DOLLAR-NEUTRAL CONSTRUCTION: PnL of the spread position is
        pos * (dP_B - beta * dP_A)
   which is exactly long/short one spread unit.
"""

import numpy as np
import pandas as pd


def backtest_pair(prices, beta, positions, cost_bps=5.0):
    """
    Parameters
    ----------
    prices    : DataFrame with columns [asset_a, asset_b]
    beta      : hedge ratio from the cointegrating regression
    positions : Series in {-1, 0, +1}, SAME index as prices
    cost_bps  : one-way transaction cost in basis points of traded notional
                (5 bps = 0.05%, a reasonable all-in figure for liquid US equities)

    Returns
    -------
    DataFrame with daily strategy PnL, costs, and cumulative equity curve.
    """
    a = prices.iloc[:, 0]
    b = prices.iloc[:, 1]

    # ---- 1. lag the signal: trade tomorrow on today's signal ----------
    pos = positions.shift(1).fillna(0.0)

    # ---- 2. daily PnL of one spread unit -------------------------------
    dpa = a.diff().fillna(0.0)
    dpb = b.diff().fillna(0.0)
    gross_pnl = pos * (dpb - beta * dpa)

    # ---- 3. transaction costs on position CHANGES ----------------------
    trades = pos.diff().abs().fillna(0.0)          # 0, 1 or 2 spread units
    notional_per_unit = b.abs() + beta * a.abs()   # $ traded per spread unit
    costs = trades * notional_per_unit * (cost_bps / 1e4)

    net_pnl = gross_pnl - costs

    # ---- 4. convert $ PnL into returns on deployed capital --------------
    # We size returns against the average notional of one spread unit,
    # a simple and transparent capital convention.
    capital = notional_per_unit.mean()
    returns = net_pnl / capital

    out = pd.DataFrame({
        "position": pos,
        "gross_pnl": gross_pnl,
        "costs": costs,
        "net_pnl": net_pnl,
        "returns": returns,
    })
    out["equity"] = (1 + out["returns"]).cumprod()
    return out
