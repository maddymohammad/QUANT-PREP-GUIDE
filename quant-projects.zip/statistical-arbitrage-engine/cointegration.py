"""
cointegration.py
----------------
Statistical machinery for deciding whether two assets are tradeable
as a mean-reverting pair.

Key ideas
---------
1. Two price series are COINTEGRATED if some linear combination of them
   (the "spread") is stationary, i.e. it wobbles around a fixed mean
   instead of wandering off forever.
2. We find that linear combination with an OLS regression:
        P_B = alpha + beta * P_A + residual
   The residual IS the spread.
3. We test the residual for stationarity with the Augmented
   Dickey-Fuller (ADF) test.  This two-step procedure is the classic
   Engle-Granger method.
4. We also estimate the spread's HALF-LIFE of mean reversion — how many
   days it takes a deviation to shrink by half.  Traders use it to size
   look-back windows and to reject pairs that revert too slowly.
"""

import numpy as np
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller


def estimate_hedge_ratio(price_a, price_b):
    """
    OLS regression  P_B = alpha + beta * P_A.

    Returns
    -------
    alpha : float   intercept
    beta  : float   hedge ratio (how many units of A hedge one unit of B)
    spread: np.ndarray  the regression residuals = the tradeable spread
    """
    X = sm.add_constant(np.asarray(price_a))       # adds intercept column
    y = np.asarray(price_b)
    model = sm.OLS(y, X).fit()
    alpha, beta = model.params
    spread = y - (alpha + beta * np.asarray(price_a))
    return alpha, beta, spread


def engle_granger_test(price_a, price_b):
    """
    Full Engle-Granger cointegration test.

    Returns a dict with the hedge ratio, ADF statistic and p-value.
    Rule of thumb: p-value < 0.05  ->  the pair is cointegrated at the
    5% significance level.
    """
    alpha, beta, spread = estimate_hedge_ratio(price_a, price_b)
    adf_stat, p_value, *_ = adfuller(spread, autolag="AIC")
    return {
        "alpha": alpha,
        "beta": beta,
        "spread": spread,
        "adf_stat": adf_stat,
        "p_value": p_value,
        "cointegrated_5pct": p_value < 0.05,
    }


def half_life(spread):
    """
    Estimate the mean-reversion half-life of the spread.

    We fit an AR(1)-style regression:
        dS_t = lambda * S_{t-1} + noise
    If lambda < 0 the spread mean-reverts, and
        half_life = -ln(2) / lambda   (in days).
    """
    spread = np.asarray(spread)
    lagged = spread[:-1]
    delta = np.diff(spread)
    X = sm.add_constant(lagged)
    model = sm.OLS(delta, X).fit()
    lam = model.params[1]
    if lam >= 0:
        return np.inf  # no mean reversion detected
    return -np.log(2) / lam
