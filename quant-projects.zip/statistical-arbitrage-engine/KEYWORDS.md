# KEYWORDS.md — Every step of this project explained

This file is your study companion. It has two parts:
**Part A** explains every Python keyword and construct used in the code.
**Part B** walks through each file, step by step, explaining what the code does and *why*.

---

## PART A — Python keywords & constructs used in this project

### `import` / `from ... import ...`
Brings code from another file (a "module") into the current one.
`import numpy as np` loads the NumPy library and nicknames it `np`, so you write `np.log(...)` instead of `numpy.log(...)`. `from signals import rolling_zscore` grabs one specific function from our own `signals.py` file.

### `def`
Defines a function. `def sharpe_ratio(returns, rf=0.0):` creates a function named `sharpe_ratio` taking a required argument `returns` and an optional one `rf` whose **default value** is `0.0` (used if the caller doesn't supply it).

### `return`
Exits a function and hands a value back to whoever called it. A function can return several things at once as a tuple: `return alpha, beta, spread`.

### `"""docstring"""`
The triple-quoted text right under a `def` or at the top of a file. It's documentation, not executed code. Professional Python code always has docstrings — reviewers notice.

### `if` / `elif` / `else`
Branching. `elif` means "else if". Only the first true branch runs.

### `for t in range(1, n_days):`
A loop. `range(1, n_days)` produces the integers 1, 2, ..., n_days-1 (the end is *exclusive*). `t` takes each value in turn.

### `raise ValueError("...")`
Deliberately crashes with an error message when inputs are invalid. Failing loudly beats silently returning garbage — a core engineering value in finance, where silent errors cost money.

### `try` / `except`
Attempts risky code (`try`), and if it throws an error, runs the fallback (`except`) instead of crashing. We use it to fall back to synthetic data when the internet download fails.

### `lambda`
A one-line anonymous function. `f = lambda x: x + 1` is shorthand for a tiny `def`.

### `f-strings` — `f"beta = {beta:.4f}"`
String with values injected inside `{}`. The `:.4f` means "format as a decimal with 4 digits after the point". `:.2%` formats 0.0213 as "2.13%".

### `*_` in `adf_stat, p_value, *_ = adfuller(...)`
The function returns many values; we keep the first two and dump the rest into a throwaway variable `_` (the `*` means "collect everything remaining").

### `tuple` vs `list` vs `dict`
- `("KO", "PEP")` — tuple: ordered, unchangeable.
- `[1, 2, 3]` — list: ordered, changeable.
- `{"beta": 1.43, "p_value": 0.0001}` — dict: named key→value pairs. Access with `res["beta"]`.

### `**kwargs`
"Keyword arguments." Lets a function accept extra named arguments and pass them along: `load_prices(use_live=False, **kwargs)` forwards anything else to the simulator.

### `if __name__ == "__main__":`
Standard Python idiom. Code under this line runs only when you execute the file directly (`python main.py`), not when another file imports it. It's how you separate "library code" from "script code".

### `argparse`
Standard library for reading command-line options, so `python main.py --entry 1.5` changes the entry threshold without editing code.

---

## PART B — NumPy / pandas constructs (the quant's daily tools)

### `np.random.default_rng(seed)`
Creates a random-number generator. Fixing `seed=42` makes the "random" numbers identical every run → **reproducibility**, which is essential in research.

### `rng.standard_normal(n)`
Draws `n` samples from the standard normal distribution N(0, 1) — the building block of almost all financial simulation.

### `np.cumsum(x)`
Cumulative sum: `[1, 2, 3] → [1, 3, 6]`. Summing random log-returns cumulatively builds a random-walk log-price path.

### `np.exp` / `np.log`
Element-wise exponential / natural log. We simulate **log prices** and exponentiate because log prices can go negative safely while real prices cannot.

### `pd.Series` / `pd.DataFrame`
pandas' 1-column and multi-column tables, both carrying an **index** (here: dates). Nearly all real quant data lives in DataFrames.

### `s.rolling(window).mean()` / `.std()`
Moving average / moving standard deviation over the last `window` observations. Produces `NaN` (not-a-number) until enough history accumulates.

### `.shift(1)`
Moves a series down by one row: today's slot now holds yesterday's value. **This one method call is what prevents look-ahead bias** — we trade *tomorrow* on *today's* signal.

### `.diff()`
Day-over-day change: `x_t − x_{t−1}`. Used for price changes (PnL) and for detecting position changes (trades).

### `.fillna(0.0)`
Replaces NaN with 0 — e.g. the first `.diff()` value has no predecessor.

### `.cumprod()` and `(1 + returns).cumprod()`
Cumulative product. Compounds a return series into an **equity curve**: money grows multiplicatively, not additively.

### `.cummax()`
Running maximum — used to measure drawdowns from the highest point so far.

### `sm.add_constant(X)` and `sm.OLS(y, X).fit()`
statsmodels' linear regression. `add_constant` appends the intercept column; `.fit()` runs Ordinary Least Squares and `.params` holds the fitted coefficients.

### `adfuller(spread)`
The **Augmented Dickey-Fuller test** from statsmodels. Null hypothesis: the series has a unit root (it wanders like a random walk). A small p-value (< 0.05) rejects that → the spread is stationary → the pair is cointegrated.

---

## PART C — File-by-file walkthrough

### 1. `data_loader.py` — getting prices

**Step 1 — `load_live_prices`:** downloads real adjusted prices via `yfinance`. "Adjusted" means dividends and splits are folded into the price so returns are economically correct.

**Step 2 — `simulate_cointegrated_pair`:** builds a *controlled experiment*.
- Asset A: log price = starting log price + cumulative sum of `drift + vol * noise`. This is a **geometric random walk**, the discrete cousin of Geometric Brownian Motion.
- The spread follows an **Ornstein-Uhlenbeck (OU) process**: `S_t = S_{t-1} + kappa*(0 − S_{t-1}) + sigma*noise`. The `kappa*(0 − S)` term is a rubber band pulling the spread back to 0 — mean reversion by construction.
- Asset B = `beta * A + spread`. So the pair is cointegrated *by design*, and we know the true hedge ratio (1.5) — letting us verify our estimator recovers it (it estimates ≈1.43 from noisy data; close).

**Step 3 — `load_prices`:** one clean entry point. Tries live data, falls back to simulation. This "graceful degradation" pattern is good software design.

### 2. `cointegration.py` — is the pair tradeable?

**Step 1 — `estimate_hedge_ratio`:** regress `P_B` on `P_A`. The slope β tells you how many units of A hedge one unit of B. The **residuals of this regression are the spread** we will trade.

**Step 2 — `engle_granger_test`:** run the ADF test on those residuals. This two-step recipe (regress, then ADF the residuals) is the **Engle-Granger method** — Engle and Granger won the 2003 Nobel Prize partly for cointegration. If p < 0.05, deviations of the spread are temporary → statistically justified to bet on reversion.

**Step 3 — `half_life`:** regress the spread's daily *change* on its lagged *level*: `dS_t = λ·S_{t−1} + noise`. If λ < 0, deviations decay, and half-life = −ln(2)/λ days. Our run prints ≈15.6 days: deviations halve in about three trading weeks — fast enough to trade with a 60-day window.

### 3. `signals.py` — from spread to trades

**Step 1 — `rolling_zscore`:** standardize the spread using only *past* data: `z = (spread − rolling mean) / rolling std`. z answers "how many standard deviations from normal is the spread *right now*?"

**Step 2 — `generate_positions`:** a small state machine:
- flat and z > +2 → go **short** the spread (it's rich; bet it falls);
- flat and z < −2 → go **long** the spread (it's cheap);
- in a position and z crosses back inside ±0.5 → **close**.
The gap between entry (2.0) and exit (0.5) is hysteresis — it stops the strategy churning in and out on noise, which would bleed transaction costs.

### 4. `backtester.py` — honest simulation

**Step 1 — signal lag:** `positions.shift(1)`. A signal computed from today's close cannot be traded at today's close. Skipping this shift inflates performance and is the most common backtest fraud (usually accidental).

**Step 2 — PnL:** holding one spread unit long earns `ΔP_B − β·ΔP_A` per day. Multiply by the position (−1/0/+1).

**Step 3 — costs:** every position *change* trades notional ≈ `|P_B| + β·|P_A|`; we charge 5 basis points (0.05%) of it. Watch "Total cost drag" in the output — costs are why marginal strategies fail in production.

**Step 4 — returns & equity:** divide $ PnL by a capital base and compound with `cumprod` into the equity curve.

### 5. `metrics.py` — how good is it?

- **Sharpe ratio** = annualized excess return / annualized volatility. The √252 appears because volatility scales with the square root of time. Rule of thumb: >1 is respectable for a simple daily strategy.
- **Sortino** = Sharpe but penalizing only downside volatility.
- **Max drawdown** = worst peak-to-trough loss; the number that gets funds fired.
- **Calmar** = CAGR / |max drawdown|; return per unit of worst pain.

### 6. `main.py` — the pipeline

Load → test cointegration (refuse to trade a non-cointegrated pair!) → signals → backtest → metrics table → three-panel plot (prices, z-score with bands, equity curve) saved to `results.png`.

---

## PART D — Interview questions this project prepares you for

1. *What is cointegration and how does it differ from correlation?* (Correlation is about co-movement of returns; cointegration is about a stationary long-run relationship between price **levels**.)
2. *What is look-ahead bias and where could it hide here?* (Full-sample z-score; missing signal lag; even estimating β on the full sample — a great extension is rolling/out-of-sample β.)
3. *Why can a high-Sharpe gross strategy lose money net?* (Cost per trade × turnover.)
4. *What is the half-life of mean reversion and why do traders care?*
5. *What would break this strategy live?* (Structural breaks — the relationship dies, e.g. one company gets acquired; the spread then diverges and stop-losses matter.)
