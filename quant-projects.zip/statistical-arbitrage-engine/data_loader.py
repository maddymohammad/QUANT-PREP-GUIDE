"""
data_loader.py
--------------
Loads price data for the pairs-trading strategy.

Two modes:
1. LIVE mode  -> downloads real daily prices from Yahoo Finance (needs `yfinance`).
2. SYNTHETIC  -> simulates two cointegrated price series so the whole
                 project runs offline and is 100% reproducible.

Reproducibility matters: an admissions reviewer (or interviewer) can clone
your repo and get the exact same numbers you report in the README.
"""

import numpy as np
import pandas as pd


def load_live_prices(tickers, start="2018-01-01", end=None):
    """
    Download adjusted close prices from Yahoo Finance.

    Parameters
    ----------
    tickers : list[str]   e.g. ["KO", "PEP"]
    start, end : str      ISO dates, e.g. "2018-01-01"

    Returns
    -------
    pd.DataFrame with one column per ticker, indexed by date.
    """
    import yfinance as yf  # imported here so the rest of the project
    # works even if yfinance is not installed
    data = yf.download(tickers, start=start, end=end, auto_adjust=True)
    prices = data["Close"].dropna()
    return prices


def simulate_cointegrated_pair(
    n_days=1500,
    seed=42,
    p0_a=100.0,
    hedge_ratio=1.5,
    spread_kappa=0.05,
    spread_sigma=0.6,
    drift=0.0002,
    vol=0.012,
):
    """
    Simulate two price series that are COINTEGRATED by construction.

    Idea:
      - Asset A follows a random walk with drift (like a real stock).
      - The *spread*  S_t = P_B - beta * P_A  follows an
        Ornstein-Uhlenbeck (OU) process: it keeps getting pulled back
        toward zero.  That mean-reversion is exactly what a pairs
        trader tries to monetise.
      - Asset B is then defined as  P_B = beta * P_A + S_t.

    Parameters
    ----------
    n_days       : number of trading days to simulate
    seed         : random seed (fixes the randomness -> reproducible)
    p0_a         : starting price of asset A
    hedge_ratio  : the "true" beta linking the two assets
    spread_kappa : OU mean-reversion speed (higher = snaps back faster)
    spread_sigma : OU noise volatility
    drift, vol   : daily drift and volatility of asset A's log price

    Returns
    -------
    pd.DataFrame with columns ["ASSET_A", "ASSET_B"] and a business-day index.
    """
    rng = np.random.default_rng(seed)

    # --- Asset A: geometric random walk on log prices -------------------
    log_returns = drift + vol * rng.standard_normal(n_days)
    log_price_a = np.log(p0_a) + np.cumsum(log_returns)
    price_a = np.exp(log_price_a)

    # --- Spread: discretised Ornstein-Uhlenbeck process ------------------
    # S_{t+1} = S_t + kappa * (0 - S_t) + sigma * eps_t
    spread = np.zeros(n_days)
    shocks = rng.standard_normal(n_days)
    for t in range(1, n_days):
        spread[t] = spread[t - 1] + spread_kappa * (0.0 - spread[t - 1]) \
                    + spread_sigma * shocks[t]

    # --- Asset B is tied to A through the hedge ratio --------------------
    price_b = hedge_ratio * price_a + spread

    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=n_days)
    return pd.DataFrame({"ASSET_A": price_a, "ASSET_B": price_b}, index=dates)


def load_prices(use_live=False, tickers=("KO", "PEP"), **kwargs):
    """
    Single entry point used by main.py.
    Tries live data if requested; otherwise falls back to simulation.
    """
    if use_live:
        try:
            return load_live_prices(list(tickers), **kwargs)
        except Exception as exc:  # no internet / yfinance missing
            print(f"[data_loader] Live download failed ({exc}). "
                  f"Falling back to synthetic data.")
    return simulate_cointegrated_pair(**kwargs)
