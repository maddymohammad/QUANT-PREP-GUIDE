"""
metrics.py
----------
Standard performance & risk statistics every quant desk looks at.

All formulas assume DAILY returns and annualise with 252 trading days.
"""

import numpy as np
import pandas as pd

TRADING_DAYS = 252


def sharpe_ratio(returns, rf=0.0):
    """
    Sharpe = (mean excess return / std of returns) * sqrt(252).
    Measures reward per unit of TOTAL risk.
    """
    excess = returns - rf / TRADING_DAYS
    if excess.std() == 0:
        return 0.0
    return np.sqrt(TRADING_DAYS) * excess.mean() / excess.std()


def sortino_ratio(returns, rf=0.0):
    """
    Like Sharpe but only penalises DOWNSIDE volatility —
    investors don't complain about upside surprises.
    """
    excess = returns - rf / TRADING_DAYS
    downside = excess[excess < 0].std()
    if downside == 0 or np.isnan(downside):
        return np.nan
    return np.sqrt(TRADING_DAYS) * excess.mean() / downside


def max_drawdown(equity):
    """
    Largest peak-to-trough fall of the equity curve.
    drawdown_t = equity_t / running_max_t - 1  (always <= 0).
    """
    running_max = equity.cummax()
    drawdown = equity / running_max - 1.0
    return drawdown.min()


def annualised_return(equity):
    """Compound annual growth rate (CAGR) of the equity curve."""
    n_days = len(equity)
    total = equity.iloc[-1] / equity.iloc[0]
    return total ** (TRADING_DAYS / n_days) - 1


def calmar_ratio(equity):
    """CAGR divided by |max drawdown| — return per unit of worst pain."""
    mdd = abs(max_drawdown(equity))
    if mdd == 0:
        return np.nan
    return annualised_return(equity) / mdd


def summarise(results):
    """Bundle everything into a tidy Series for printing / README tables."""
    r = results["returns"]
    eq = results["equity"]
    n_trades = int(results["position"].diff().abs().sum())
    return pd.Series({
        "Annualised return": f"{annualised_return(eq):.2%}",
        "Annualised vol": f"{r.std() * np.sqrt(TRADING_DAYS):.2%}",
        "Sharpe ratio": f"{sharpe_ratio(r):.2f}",
        "Sortino ratio": f"{sortino_ratio(r):.2f}",
        "Max drawdown": f"{max_drawdown(eq):.2%}",
        "Calmar ratio": f"{calmar_ratio(eq):.2f}",
        "Round-trip trades": n_trades // 2,
        "Total cost drag ($)": f"{results['costs'].sum():.2f}",
    })
