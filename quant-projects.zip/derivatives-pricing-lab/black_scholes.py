"""
black_scholes.py
----------------
Closed-form Black-Scholes-Merton pricing for European options,
plus the full set of first-order Greeks.

Notation (used across the whole project):
    S     : current price of the underlying
    K     : strike price
    T     : time to expiry, in YEARS (e.g. 0.5 = six months)
    r     : continuously-compounded risk-free rate (e.g. 0.05 = 5%)
    sigma : annualised volatility of the underlying (e.g. 0.2 = 20%)
    q     : continuous dividend yield

The model assumes the stock follows Geometric Brownian Motion:
    dS = (r - q) S dt + sigma S dW      (under the risk-neutral measure)
"""

import numpy as np
from scipy.stats import norm


def _d1_d2(S, K, T, r, sigma, q=0.0):
    """The two famous intermediate quantities in the BSM formula."""
    d1 = (np.log(S / K) + (r - q + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    return d1, d2


def price(S, K, T, r, sigma, q=0.0, kind="call"):
    """
    Black-Scholes-Merton price of a European call or put.

    call = S e^{-qT} N(d1) - K e^{-rT} N(d2)
    put  = K e^{-rT} N(-d2) - S e^{-qT} N(-d1)
    """
    d1, d2 = _d1_d2(S, K, T, r, sigma, q)
    if kind == "call":
        return S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    elif kind == "put":
        return K * np.exp(-r * T) * norm.cdf(-d2) - S * np.exp(-q * T) * norm.cdf(-d1)
    raise ValueError("kind must be 'call' or 'put'")


def greeks(S, K, T, r, sigma, q=0.0, kind="call"):
    """
    Analytic Greeks — the sensitivities a trading desk hedges with.

    delta : dV/dS      (per $1 move in the underlying)
    gamma : d2V/dS2    (how fast delta itself changes)
    vega  : dV/dsigma  (per 1.00 change in vol; divide by 100 for per vol-point)
    theta : dV/dT      (time decay, per YEAR; divide by 365 for per day)
    rho   : dV/dr      (per 1.00 change in rates)
    """
    d1, d2 = _d1_d2(S, K, T, r, sigma, q)
    pdf_d1 = norm.pdf(d1)
    disc_q = np.exp(-q * T)
    disc_r = np.exp(-r * T)

    gamma = disc_q * pdf_d1 / (S * sigma * np.sqrt(T))
    vega = S * disc_q * pdf_d1 * np.sqrt(T)

    if kind == "call":
        delta = disc_q * norm.cdf(d1)
        theta = (-S * disc_q * pdf_d1 * sigma / (2 * np.sqrt(T))
                 - r * K * disc_r * norm.cdf(d2)
                 + q * S * disc_q * norm.cdf(d1))
        rho = K * T * disc_r * norm.cdf(d2)
    else:
        delta = -disc_q * norm.cdf(-d1)
        theta = (-S * disc_q * pdf_d1 * sigma / (2 * np.sqrt(T))
                 + r * K * disc_r * norm.cdf(-d2)
                 - q * S * disc_q * norm.cdf(-d1))
        rho = -K * T * disc_r * norm.cdf(-d2)

    return {"delta": delta, "gamma": gamma, "vega": vega,
            "theta": theta, "rho": rho}
