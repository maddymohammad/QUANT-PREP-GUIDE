"""
binomial_tree.py
----------------
Cox-Ross-Rubinstein (CRR) binomial tree.

Why bother when we have Black-Scholes?
    1. It prices AMERICAN options (early exercise), which have no
       closed-form solution.
    2. As the number of steps N grows, the European tree price converges
       to the Black-Scholes price — a beautiful numerical check that
       both implementations are correct.

Tree mechanics:
    Each step of length dt = T/N the price moves
        up   by factor u = exp(sigma * sqrt(dt))
        down by factor d = 1/u
    with RISK-NEUTRAL probability
        p = (exp((r - q) dt) - d) / (u - d).
    We then discount expected payoffs backwards through the tree.
"""

import numpy as np


def price(S, K, T, r, sigma, q=0.0, kind="call", american=False, steps=500):
    """
    CRR binomial price of a call/put, European or American.

    Implementation is fully vectorised: at each time slice we operate on
    the whole layer of nodes with NumPy instead of looping node by node.
    """
    dt = T / steps
    u = np.exp(sigma * np.sqrt(dt))
    d = 1.0 / u
    disc = np.exp(-r * dt)
    p = (np.exp((r - q) * dt) - d) / (u - d)
    if not (0.0 < p < 1.0):
        raise ValueError("Risk-neutral probability outside (0,1): "
                         "check inputs (sigma too small vs r?)")

    # Stock prices at maturity: S * u^j * d^(N-j), j = 0..N
    j = np.arange(steps + 1)
    ST = S * (u ** j) * (d ** (steps - j))

    # Option payoffs at maturity
    if kind == "call":
        values = np.maximum(ST - K, 0.0)
    else:
        values = np.maximum(K - ST, 0.0)

    # Backward induction through the tree
    for step in range(steps - 1, -1, -1):
        # continuation value = discounted risk-neutral expectation
        values = disc * (p * values[1:] + (1 - p) * values[:-1])
        if american:
            j = np.arange(step + 1)
            S_nodes = S * (u ** j) * (d ** (step - j))
            intrinsic = (np.maximum(S_nodes - K, 0.0) if kind == "call"
                         else np.maximum(K - S_nodes, 0.0))
            # holder exercises early whenever intrinsic > continuation
            values = np.maximum(values, intrinsic)

    return float(values[0])
