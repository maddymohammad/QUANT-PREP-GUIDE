"""
implied_vol.py
--------------
Implied volatility: the sigma that makes the Black-Scholes price equal
an observed market price.  It is THE quoting convention of options
markets — traders talk in vols, not dollars.

We solve  BS(sigma) - market_price = 0  with Brent's root-finding method
(robust: guaranteed to converge if the root is bracketed, unlike plain
Newton-Raphson which can shoot off when vega is tiny).

We also build a synthetic VOLATILITY SMILE: real markets do not obey
Black-Scholes' constant-sigma assumption, so out-of-the-money puts
(crash insurance) trade at higher implied vols — the famous "skew"
that appeared after the 1987 crash.
"""

import numpy as np
from scipy.optimize import brentq

import black_scholes as bs


def implied_vol(market_price, S, K, T, r, q=0.0, kind="call",
                lo=1e-4, hi=5.0):
    """
    Invert Black-Scholes for sigma using Brent's method.

    Raises ValueError if the market price violates no-arbitrage bounds
    (i.e. no sigma in [lo, hi] can reproduce it).
    """
    f = lambda sigma: bs.price(S, K, T, r, sigma, q, kind) - market_price
    if f(lo) * f(hi) > 0:
        raise ValueError("Market price outside attainable Black-Scholes range")
    return brentq(f, lo, hi, xtol=1e-10)


def synthetic_smile(S=100.0, T=0.5, r=0.05, q=0.0,
                    strikes=None, base_vol=0.20, skew=-0.10, curvature=0.35):
    """
    Generate 'market' option prices from a smile-shaped true vol curve,
    then recover that curve via the implied-vol solver.

    True vol as a function of log-moneyness m = ln(K/S):
        sigma(m) = base_vol + skew * m + curvature * m^2
    (negative skew -> low strikes have HIGHER vol, as in equity markets)

    Returns (strikes, true_vols, recovered_vols) — the last two should
    match to ~1e-8, proving the solver works.
    """
    if strikes is None:
        strikes = np.linspace(70, 130, 25)
    m = np.log(strikes / S)
    true_vols = base_vol + skew * m + curvature * m ** 2

    market_prices = np.array([
        bs.price(S, K, T, r, sig, q, "call")
        for K, sig in zip(strikes, true_vols)
    ])
    recovered = np.array([
        implied_vol(p, S, K, T, r, q, "call")
        for p, K in zip(market_prices, strikes)
    ])
    return strikes, true_vols, recovered
