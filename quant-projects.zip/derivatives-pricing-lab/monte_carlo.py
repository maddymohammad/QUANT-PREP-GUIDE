"""
monte_carlo.py
--------------
Monte Carlo pricing under Geometric Brownian Motion, with:

    * exact log-normal terminal simulation for European options,
    * ANTITHETIC VARIATES variance reduction,
    * a standard error so we can report a confidence interval
      (a Monte Carlo price without an error bar is meaningless),
    * full path simulation used to price a path-dependent
      (arithmetic Asian) option that Black-Scholes cannot handle.

Risk-neutral pricing principle:
    price = e^{-rT} * E[ payoff ]  under the risk-neutral measure,
and Monte Carlo estimates that expectation with a sample average.
"""

import numpy as np


def european_price(S, K, T, r, sigma, q=0.0, kind="call",
                   n_paths=200_000, seed=7, antithetic=True):
    """
    Price a European option by simulating the terminal stock price:

        S_T = S * exp((r - q - 0.5 sigma^2) T + sigma sqrt(T) Z),  Z ~ N(0,1)

    Antithetic variates: for every draw Z we also use -Z.
    The two payoffs are negatively correlated, so their average has
    lower variance -> tighter error bars for the same compute budget.

    Returns (price, standard_error).
    """
    rng = np.random.default_rng(seed)
    n = n_paths // 2 if antithetic else n_paths
    Z = rng.standard_normal(n)
    if antithetic:
        Z = np.concatenate([Z, -Z])

    drift = (r - q - 0.5 * sigma ** 2) * T
    ST = S * np.exp(drift + sigma * np.sqrt(T) * Z)

    payoff = np.maximum(ST - K, 0.0) if kind == "call" else np.maximum(K - ST, 0.0)
    disc_payoff = np.exp(-r * T) * payoff

    price = disc_payoff.mean()
    stderr = disc_payoff.std(ddof=1) / np.sqrt(len(disc_payoff))
    return price, stderr


def simulate_paths(S, T, r, sigma, q=0.0, n_paths=50_000, n_steps=252, seed=7):
    """
    Simulate full GBM paths on a grid of n_steps time points.
    Needed for PATH-DEPENDENT payoffs (Asians, barriers, lookbacks).

    Returns array of shape (n_paths, n_steps + 1) including t=0.
    """
    rng = np.random.default_rng(seed)
    dt = T / n_steps
    Z = rng.standard_normal((n_paths, n_steps))
    increments = (r - q - 0.5 * sigma ** 2) * dt + sigma * np.sqrt(dt) * Z
    log_paths = np.cumsum(increments, axis=1)
    paths = S * np.exp(np.hstack([np.zeros((n_paths, 1)), log_paths]))
    return paths


def asian_price(S, K, T, r, sigma, q=0.0, kind="call",
                n_paths=50_000, n_steps=252, seed=7):
    """
    Arithmetic-average Asian option:
        payoff = max(mean(S_t over the path) - K, 0)   for a call.

    Averaging smooths the terminal distribution, so Asians are CHEAPER
    than their European counterparts — a good sanity check.
    """
    paths = simulate_paths(S, T, r, sigma, q, n_paths, n_steps, seed)
    avg = paths[:, 1:].mean(axis=1)
    payoff = np.maximum(avg - K, 0.0) if kind == "call" else np.maximum(K - avg, 0.0)
    disc_payoff = np.exp(-r * T) * payoff
    return disc_payoff.mean(), disc_payoff.std(ddof=1) / np.sqrt(n_paths)
