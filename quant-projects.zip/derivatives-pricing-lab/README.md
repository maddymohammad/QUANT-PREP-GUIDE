# Derivatives Pricing Lab — Black-Scholes, Binomial Trees & Monte Carlo

A from-scratch option pricing library with three independent engines that cross-validate each other, analytic Greeks, an implied-volatility solver, and a volatility-smile recovery experiment. No pricing package dependencies — every formula is implemented and tested by hand.

## What's inside

| Engine | Handles | Validated against |
|---|---|---|
| **Black-Scholes** (closed form) | European calls/puts + all first-order Greeks | — (the benchmark) |
| **CRR binomial tree** (vectorised) | European **and American** options | Converges to BS (diff 4e-4 at 2000 steps) |
| **Monte Carlo** (antithetic variates) | European + path-dependent **Asian** options | BS lies inside the 95% confidence interval |

Plus:
- **Implied vol solver** (Brent's method) with no-arbitrage bound checks.
- **Volatility smile experiment**: generate market prices from a skewed "true" vol curve, then recover the smile to ~1e-11 max error — a round-trip proof of correctness.

## Headline results (S=100, K=105, T=0.5y, r=5%, σ=20%)

```
Black-Scholes call : 4.5817
Binomial (2000)    : 4.5820   (abs diff 0.00037)
Monte Carlo        : 4.5667 ± 0.0358 (95% CI, contains BS ✓)

American put 7.4367 vs European put 6.9896  → early-exercise premium 0.4471
Asian call 1.7873 « European 4.5817          → averaging effect confirmed
Smile recovery max error: 2.0e-11
```

![results](results.png)

Panels: (a) binomial convergence to Black-Scholes, (b) Delta & Gamma across spot, (c) implied-vol solver recovering the smile.

## Run it

```bash
pip install -r requirements.txt
python main.py
```

## Why cross-validation matters

A single pricer that "looks right" proves nothing. Three methods built on different mathematics (a closed-form PDE solution, a discrete lattice, and stochastic simulation) agreeing to within numerical tolerance — and satisfying no-arbitrage inequalities (American ≥ European, Asian < European) — is how production pricing libraries are actually tested.

## Concepts demonstrated

Risk-neutral pricing · Geometric Brownian Motion & the Itô correction · backward induction · early-exercise premium · variance reduction (antithetic variates) · Monte Carlo standard errors · Greeks and the theta–gamma trade-off · implied volatility and the post-1987 skew.

## Extensions I'd build next

Implicit finite-difference PDE solver (a fourth engine), control variates (geometric Asian as control for arithmetic), Heston stochastic volatility, Longstaff-Schwartz for American Monte Carlo.

## Project structure

```
black_scholes.py  # closed-form prices + analytic Greeks
binomial_tree.py  # vectorised CRR tree, European & American
monte_carlo.py    # exact terminal & full-path GBM, antithetic, Asians
implied_vol.py    # Brent solver + synthetic smile recovery
main.py           # cross-validation harness + plots
KEYWORDS.md       # line-by-line explanation of every concept used
```
