# KEYWORDS.md — Every step of this project explained

**Part A**: Python keywords/constructs used here (only ones NOT already covered in the stat-arb project's KEYWORDS.md are re-explained in depth).
**Part B**: file-by-file walkthrough of the math and the code.

---

## PART A — Python & NumPy constructs in this project

### `import black_scholes as bs`
You can import your *own* files, not just libraries. Any `.py` file in the same folder is importable. This is how you split a project into clean modules.

### Default arguments — `def price(S, K, T, r, sigma, q=0.0, kind="call")`
Callers must supply `S, K, T, r, sigma`; `q` and `kind` are optional. Calling `price(100, 105, 0.5, 0.05, 0.2, kind="put")` uses a **keyword argument** to skip `q`.

### `dict` return values
`greeks()` returns `{"delta": ..., "gamma": ...}` so callers access results by name — clearer than remembering positions in a tuple.

### `np.arange(steps + 1)`
Integer array `[0, 1, ..., steps]`. Combined with array exponentiation `u ** j` this computes **all tree nodes at once** — no per-node loop. This is called **vectorization**, and it's why NumPy code is 100× faster than plain Python loops.

### `np.maximum(a, b)`
*Element-wise* max of two arrays — perfect for option payoffs `max(S − K, 0)` applied to thousands of terminal prices simultaneously. (Note: `np.max` is different — it finds the single largest element.)

### Slicing — `values[1:]` and `values[:-1]`
`values[1:]` drops the first element; `values[:-1]` drops the last. In the tree's backward step, `p * values[1:] + (1-p) * values[:-1]` pairs every node with its up-child and down-child in one shot.

### `range(steps - 1, -1, -1)`
A loop that counts **backwards**: steps−1, steps−2, ..., 0. Option trees are solved from expiry back to today ("backward induction").

### `np.concatenate` / `np.hstack`
Glue arrays together. Used for antithetic pairs `[Z, −Z]` and to prepend the t=0 column to simulated paths.

### 2-D arrays and `axis`
`rng.standard_normal((n_paths, n_steps))` is a matrix: one row per simulated path. `.mean(axis=1)` averages **across each row** (each path's time-average), while `axis=0` would average across paths. Getting `axis` right is half of NumPy fluency.

### `np.cumsum(x, axis=1)`
Cumulative sum along each row — turns per-step log-returns into full log-price paths for thousands of paths at once.

### `scipy.stats.norm`
`norm.cdf(x)` = N(x), the standard normal cumulative distribution — the workhorse inside Black-Scholes. `norm.pdf(x)` is the bell-curve density, used in the Greeks.

### `scipy.optimize.brentq(f, lo, hi)`
Finds x where f(x) = 0, given that f(lo) and f(hi) have opposite signs (a "bracket"). Brent's method is the robust default for 1-D root finding — safer than Newton-Raphson when the derivative (vega) gets tiny for deep in/out-of-the-money options.

### `list comprehension` — `[tree.price(...) for n in steps_grid]`
Builds a list by looping in one line. Read it right-to-left: "for each n in steps_grid, compute tree.price(...), collect the results."

### `matplotlib.use("Agg")` and `twinx()`
"Agg" renders plots to files without needing a display (server-friendly). `twinx()` overlays a second y-axis so Delta (0–1) and Gamma (~0.03) can share one chart.

### `float(values[0])`
Converts a NumPy scalar to a plain Python number — a tidy return type for library functions.

---

## PART B — File-by-file walkthrough (math + code)

### 1. `black_scholes.py` — the closed-form benchmark

**The model.** Black-Scholes assumes the stock follows **Geometric Brownian Motion (GBM)**: `dS = (r − q)S dt + σS dW` under the *risk-neutral measure*. Risk-neutral pricing is the deepest idea in the file: to price a derivative you may pretend all assets drift at the risk-free rate and then discount expected payoffs at that same rate. (Why: you can replicate the option with a continuously rebalanced stock+bond portfolio, so its price cannot depend on anyone's risk appetite — otherwise arbitrage.)

**Step 1 — `_d1_d2`.** The two standardized quantities in the formula. The leading underscore in `_d1_d2` is a Python convention meaning "internal helper, not part of the public interface." Intuition: `N(d2)` = risk-neutral probability the option finishes in-the-money; `N(d1)` is the same probability under a share-denominated measure (advanced but interview-famous).

**Step 2 — `price`.** Direct implementation of `call = S e^{−qT} N(d1) − K e^{−rT} N(d2)`. Sanity anchor from our run: S=100, K=105, T=0.5, r=5%, σ=20% → call ≈ **4.58**.

**Step 3 — `greeks`.** The desk's hedging dashboard:
- **Delta** (≈0.46 here): shares of stock to hold against a short option to be locally immune to price moves.
- **Gamma**: how fast delta changes; large near the strike, near expiry. Gamma is *why* hedges must be rebalanced.
- **Vega** (28.1): P&L per unit of volatility change — options are really bets on σ.
- **Theta** (−7.69/year): the rent you pay for owning gamma. Note the theta–gamma trade-off: long gamma ⇒ negative theta.
- **Rho**: rate sensitivity, small for short-dated equity options.

### 2. `binomial_tree.py` — numerical engine for American options

**Step 1 — tree parameters.** Over each step dt, price multiplies by `u = e^{σ√dt}` or `d = 1/u`. The **risk-neutral probability** `p = (e^{(r−q)dt} − d)/(u − d)` is chosen so the expected one-step growth matches the risk-free rate — the discrete version of risk-neutral pricing. We `raise ValueError` if p leaves (0,1): that means the inputs admit arbitrage in the discretization.

**Step 2 — terminal payoffs.** After N steps there are N+1 possible prices `S·u^j·d^{N−j}`; compute all of them vectorized and apply the payoff.

**Step 3 — backward induction.** Each earlier node's value = `e^{−r dt} [p·V_up + (1−p)·V_down]` — discounted risk-neutral expectation. The slicing trick `values[1:]`/`values[:-1]` collapses each layer in one vector operation.

**Step 4 — the American twist.** At every node, holder chooses `max(continuation, intrinsic)`. That single `np.maximum` line is the entire early-exercise feature. Our run: American put 7.44 vs European 6.99 → early-exercise premium 0.45. (Why puts? Exercising early collects K now and earns interest on it. American calls on non-dividend stocks are never exercised early — classic interview question.)

**Validation:** with 2000 steps the European tree price matches Black-Scholes to 0.0004 — convergence plotted in `results.png` panel (a), showing the famous odd/even-step oscillation damping out.

### 3. `monte_carlo.py` — simulation engine

**Step 1 — the principle.** Price = `e^{−rT} E[payoff]`. Monte Carlo estimates the expectation by averaging over simulated scenarios. Error shrinks like 1/√n: 4× more paths → only 2× more accuracy, which is why variance reduction matters.

**Step 2 — exact terminal simulation.** For European payoffs you don't need whole paths; GBM has a known terminal distribution: `S_T = S·exp((r − q − σ²/2)T + σ√T·Z)`. The `−σ²/2` is the **Itô correction** — the mean of a lognormal exceeds the exponential of the mean, and this term compensates. Forgetting it is *the* classic quant bug.

**Step 3 — antithetic variates.** For each Z also use −Z. Payoffs from mirrored shocks are negatively correlated, so their average is less noisy — free accuracy.

**Step 4 — standard error.** We report `price ± 1.96·SE` (a 95% confidence interval). Our run: MC 4.567 ± 0.036, which contains the true 4.582. A Monte Carlo number without an error bar is not a result.

**Step 5 — `simulate_paths` + `asian_price`.** Full paths (a paths × steps matrix built with one `cumsum(axis=1)`) enable **path-dependent** payoffs. The arithmetic Asian call pays on the path *average*; averaging lowers variance of the effective underlying, so the Asian (1.79) is much cheaper than the European (4.58) — theory confirmed by simulation.

### 4. `implied_vol.py` — inverting the model

**Step 1 — the concept.** Markets quote option *prices*; traders think in *implied vol* — the σ that makes Black-Scholes reproduce the market price. It's the market's forecast of future volatility, and the universal quoting currency of options desks.

**Step 2 — `implied_vol`.** Define `f(σ) = BS(σ) − market_price` and hand it to `brentq` over σ ∈ [0.0001, 5]. The `lambda` builds f on the fly. We first check `f(lo)·f(hi) < 0`; if not, the market price violates no-arbitrage bounds and we raise an error rather than return nonsense.

**Step 3 — `synthetic_smile`.** Real markets show a **volatility smile/skew**: OTM puts trade at higher implied vols (crash insurance demand — the skew appeared after the 1987 crash), directly contradicting Black-Scholes' constant-σ assumption. We (i) posit a true smile σ(m) = 0.20 − 0.10m + 0.35m² in log-moneyness m = ln(K/S), (ii) generate "market" prices from it, (iii) recover the smile with our solver. Max error ≈ 2e-11 — a **round-trip test** proving pricer and solver are exact inverses.

### 5. `main.py` — cross-validation harness

The intellectual core: three *independent* methods must agree.
1. Tree (2000 steps) vs Black-Scholes: differ by 0.0004. ✓
2. Monte Carlo 95% CI contains Black-Scholes. ✓
3. American ≥ European (extra rights can't have negative value). ✓
4. Asian < European (averaging reduces variance). ✓
5. Smile recovered to machine precision. ✓

This is exactly how production pricing libraries are tested — against alternative implementations and no-arbitrage inequalities, not just eyeballed.

---

## PART C — Interview questions this project prepares you for

1. *Derive or explain d1 and d2. What is N(d2)?*
2. *Why is an American call on a non-dividend stock never exercised early?*
3. *Where does the −σ²/2 term in GBM simulation come from?* (Itô's lemma / lognormal mean.)
4. *How does Monte Carlo error scale with the number of paths? Name two variance-reduction techniques.* (Antithetic variates here; control variates as an extension.)
5. *What is the volatility smile and why does it contradict Black-Scholes?*
6. *Why use Brent instead of Newton-Raphson for implied vol?* (Vega → 0 deep ITM/OTM makes Newton unstable.)
7. *Explain the theta–gamma trade-off.*
