"""
main.py
-------
Runs the whole pricing lab and, crucially, CROSS-VALIDATES the three
independent pricing engines against each other:

    Black-Scholes (closed form)
      == Binomial tree with many steps (numerical)
      == Monte Carlo within its confidence interval (stochastic)

Three methods agreeing is far stronger evidence of correctness than any
single implementation — this is how real pricing libraries are tested.

Run with:  python main.py
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import black_scholes as bs
import binomial_tree as tree
import monte_carlo as mc
from implied_vol import synthetic_smile

# ------------------------- common test contract -------------------------
S, K, T, r, sigma, q = 100.0, 105.0, 0.5, 0.05, 0.20, 0.0

print("Contract: S=100, K=105, T=0.5y, r=5%, sigma=20%, q=0\n")

# ---------------- 1. cross-validation of the three engines ---------------
print("=== European CALL: three independent engines ===")
p_bs = bs.price(S, K, T, r, sigma, q, "call")
p_tree = tree.price(S, K, T, r, sigma, q, "call", american=False, steps=2000)
p_mc, se = mc.european_price(S, K, T, r, sigma, q, "call")
print(f"Black-Scholes  : {p_bs:.4f}")
print(f"Binomial (2000): {p_tree:.4f}   (abs diff {abs(p_tree-p_bs):.5f})")
print(f"Monte Carlo    : {p_mc:.4f} +/- {1.96*se:.4f} (95% CI)")
inside = abs(p_mc - p_bs) < 1.96 * se
print(f"BS inside MC confidence interval? {inside}\n")

# ---------------- 2. Greeks ----------------------------------------------
print("=== Analytic Greeks (call) ===")
for name, val in bs.greeks(S, K, T, r, sigma, q, "call").items():
    print(f"{name:>6}: {val: .4f}")
print()

# ---------------- 3. American vs European put ----------------------------
print("=== Early-exercise premium (put) ===")
eur_put = tree.price(S, K, T, r, sigma, q, "put", american=False, steps=2000)
amer_put = tree.price(S, K, T, r, sigma, q, "put", american=True, steps=2000)
print(f"European put : {eur_put:.4f}")
print(f"American put : {amer_put:.4f}")
print(f"Premium      : {amer_put - eur_put:.4f}  "
      f"(American >= European always — free optionality)\n")

# ---------------- 4. Path-dependent Asian option --------------------------
print("=== Arithmetic Asian call (Monte Carlo only — no closed form) ===")
asian, asian_se = mc.asian_price(S, K, T, r, sigma, q, "call")
print(f"Asian call   : {asian:.4f} +/- {1.96*asian_se:.4f}")
print(f"European call: {p_bs:.4f}  (Asian cheaper, as theory predicts)\n")

# ---------------- 5. Plots -------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))

# (a) binomial convergence to Black-Scholes
steps_grid = np.arange(10, 800, 10)
tree_prices = [tree.price(S, K, T, r, sigma, q, "call", steps=int(n))
               for n in steps_grid]
axes[0].plot(steps_grid, tree_prices, lw=0.9, label="Binomial")
axes[0].axhline(p_bs, color="red", ls="--", label="Black-Scholes")
axes[0].set_title("Binomial tree converges to Black-Scholes")
axes[0].set_xlabel("Tree steps")
axes[0].legend()

# (b) delta and gamma across spot
spots = np.linspace(60, 150, 200)
deltas = [bs.greeks(s, K, T, r, sigma, q, "call")["delta"] for s in spots]
gammas = [bs.greeks(s, K, T, r, sigma, q, "call")["gamma"] for s in spots]
ax_b = axes[1]
ax_b.plot(spots, deltas, label="Delta")
ax_b.set_ylabel("Delta")
ax_b2 = ax_b.twinx()
ax_b2.plot(spots, gammas, color="tab:orange", label="Gamma")
ax_b2.set_ylabel("Gamma")
ax_b.axvline(K, color="grey", ls=":", lw=0.8)
ax_b.set_title("Call Delta & Gamma vs spot (K=105)")
ax_b.set_xlabel("Spot price")

# (c) volatility smile recovery
strikes, true_vols, recovered = synthetic_smile(S=S, T=T, r=r)
axes[2].plot(strikes, true_vols * 100, label="True smile", lw=2)
axes[2].plot(strikes, recovered * 100, "x", label="Recovered implied vol")
axes[2].set_title("Implied-vol solver recovers the smile")
axes[2].set_xlabel("Strike")
axes[2].set_ylabel("Implied vol (%)")
axes[2].legend()

fig.tight_layout()
fig.savefig("results.png", dpi=150)
print("Max smile recovery error:", f"{np.max(np.abs(recovered-true_vols)):.2e}")
print("Saved plots to results.png")
